const AWS = require('aws-sdk');
var iam = new AWS.IAM({apiVersion: '2010-05-08'});
const express = require('express')
var dynamoDb = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });



  function sync(){
    var IAMparams = {
        MaxItems: 20
      };

      iam.listUsers(IAMparams, function(err, data) {
        if (err) {
          console.log("Error", err);
        } else {
          var users = data.Users || [];
          users.forEach((user) => {
            const input = {
                "userId": user.UserId,
                'name': user.UserName,
                'Arn': user.Arn,
                'Date': JSON.stringify(user.CreateDate),
                'showDetails': false
            }
            const params = {
                TableName: 'users-table-dev',
                Item: input
            }
            dynamoDb.put(params, (error, result) => {
                if (error) {
                  console.log(error);
                //   res.status(400).json({ error: 'Could not get user' });
                }
                console.log(input)
              });
          });
          
        }
      });
      
      
  }

  sync()

