const AWS = require('aws-sdk');

const dynamoDb = new AWS.DynamoDB.DocumentClient({ region: "us-east-1" });

function getAll(){
    var params = {
        TableName: 'users-table-dev',
        ProjectionExpression: "userId, #name, #arn, #date",
        ExpressionAttributeNames: {
            "#name": "name",
            "#arn": "Arn",
            "#date": "Date"
        }
        
      }
      console.log("Scanning table.")
      dynamoDb.scan(params, onScan)
      function onScan(err, data) {
        
            console.log('inside scan')
            if (err) {
                console.error("Unable to read item. Error JSON:", JSON.stringify(err, null, 2));
            } else {
                console.log("Scan succeeded.");
                console.log(data.Items)
    
                // continue scanning if we have more movies, because
                // scan can retrieve a maximum of 1MB of data
                if (typeof data.LastEvaluatedKey != "undefined") {
                    console.log("Scanning for more...");
                    params.ExclusiveStartKey = data.LastEvaluatedKey;
                    dynamoDb.scan(params, onScan);
                }
            }
        }
}

getAll()